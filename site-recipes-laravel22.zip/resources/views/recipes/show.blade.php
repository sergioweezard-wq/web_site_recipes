@extends('layouts.app')

@php
    $categoryLabels = [
        'Salad' => 'Салати',
        'FirstDishes' => 'Перші страви',
        'Breakfast' => 'Сніданки',
        'Starters' => 'Закуски',
        'Desserts' => 'Десерти',
    ];
@endphp

@section('content')
    <div class="container mt-3">
    <div class="d-flex align-items-start justify-content-between gap-3 flex-wrap mb-3">
        <div>
            <h2 class="fw-bold">{{ $recipe->title }}</h2>
            <div class="text-muted">{{ $categoryLabels[$recipe->category] ?? $recipe->category }}</div>
            <div class="mt-2">
                <span class="badge text-bg-secondary">{{ $recipe->calories }} ккал</span>
            </div>
        </div>
        <div>
            <a href="{{ route('recipes.index') }}" class="btn btn-outline-primary">Назад</a>
            @auth
                @if(in_array(auth()->user()->role, ['Admin', 'Redactor']))
                    <a href="{{ route('recipes.edit', $recipe) }}" class="btn btn-outline-warning ms-2">Редагувати</a>
                    <form method="post" action="{{ route('recipes.destroy', $recipe) }}" class="d-inline ms-2" onsubmit="return confirm('Видалити цей рецепт?')">
                        @csrf
                        @method('delete')
                        <button class="btn btn-outline-danger">Видалити</button>
                    </form>
                @endif
            @endauth
        </div>
    </div>

    @if($recipe->photo_path)
        <img src="{{ $recipe->photo_path }}" class="img-fluid mb-3 rounded shadow-sm recipe-photo-large" alt="{{ $recipe->title }}">
    @endif

    <div class="card border-0 shadow-sm bg-light mb-3">
        <div class="card-body">
            <h4 class="h5 fw-bold">Опис</h4>
            <p class="mb-0">{{ $recipe->description }}</p>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 mb-3">
            <div class="card border-0 shadow-sm bg-light h-100">
                <div class="card-body">
                    <h4 class="h5 fw-bold">Інгредієнти</h4>
                    <ul>
                        @foreach($recipe->ingredients->sortBy('id') as $ingredient)
                            <li>{{ $ingredient->text }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-6 mb-3">
            <div class="card border-0 shadow-sm bg-light h-100">
                <div class="card-body">
                    <h4 class="h5 fw-bold">Етапи приготування</h4>
                    <ol>
                        @foreach($recipe->steps->sortBy('step_number') as $step)
                            <li>{{ $step->text }}</li>
                        @endforeach
                    </ol>
                </div>
            </div>
        </div>
    </div>

    @auth
        <div class="mt-3">
            @if($isFavorite)
                <form method="post" action="{{ route('favorites.remove') }}">
                    @csrf
                    <input type="hidden" name="recipe_id" value="{{ $recipe->id }}">
                    <input type="hidden" name="return_url" value="{{ request()->fullUrl() }}">
                    <button class="btn btn-outline-danger">Прибрати з обраного</button>
                </form>
            @else
                <form method="post" action="{{ route('favorites.add') }}">
                    @csrf
                    <input type="hidden" name="recipe_id" value="{{ $recipe->id }}">
                    <input type="hidden" name="return_url" value="{{ request()->fullUrl() }}">
                    <button class="btn btn-outline-success">Додати в обране</button>
                </form>
            @endif
        </div>
    @endauth
    </div>
@endsection
