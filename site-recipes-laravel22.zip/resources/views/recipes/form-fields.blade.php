@php
    $categories = ['Salad', 'FirstDishes', 'Breakfast', 'Starters', 'Desserts'];
    $categoryLabels = [
        'Salad' => 'Салати',
        'FirstDishes' => 'Перші страви',
        'Breakfast' => 'Сніданки',
        'Starters' => 'Закуски',
        'Desserts' => 'Десерти',
    ];
    $ingredientsValue = old('ingredients_text');
    $stepsValue = old('steps_text');

    if ($recipe && !$ingredientsValue) {
        $ingredientsValue = $recipe->ingredients->sortBy('id')->pluck('text')->implode("\n");
    }
    if ($recipe && !$stepsValue) {
        $stepsValue = $recipe->steps->sortBy('step_number')->pluck('text')->implode("\n");
    }
@endphp

<div class="mb-3">
    <label class="form-label">Title</label>
    <input type="text" name="title" class="form-control" value="{{ old('title', $recipe->title ?? '') }}" required>
</div>

<div class="mb-3">
    <label class="form-label">Description</label>
    <textarea name="description" class="form-control" rows="4" required>{{ old('description', $recipe->description ?? '') }}</textarea>
</div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label class="form-label">Категорія</label>
        <select name="category" class="form-select" required>
            @foreach($categories as $category)
                <option value="{{ $category }}" @selected(old('category', $recipe->category ?? '') === $category)>{{ $categoryLabels[$category] }}</option>
            @endforeach
        </select>
    </div>
    <div class="col-md-6 mb-3">
        <label class="form-label">Калорії</label>
        <input type="number" step="0.1" name="calories" class="form-control" value="{{ old('calories', $recipe->calories ?? 0) }}" required>
    </div>
</div>

<div class="mb-3">
    <label class="form-label">{{ $recipe ? 'Нове фото (необов\'язково)' : 'Фото' }}</label>
    <input type="file" name="photo" class="form-control" {{ $recipe ? '' : 'required' }}>
</div>

<div class="mb-3">
    <label class="form-label">Інгредієнти (кожен з нового рядка)</label>
    <textarea name="ingredients_text" class="form-control" rows="6" required>{{ $ingredientsValue }}</textarea>
</div>

<div class="mb-3">
    <label class="form-label">Етапи приготування (кожен з нового рядка)</label>
    <textarea name="steps_text" class="form-control" rows="10" required>{{ $stepsValue }}</textarea>
</div>
