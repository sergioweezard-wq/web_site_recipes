<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class RecipeController extends Controller
{
    public function home()
    {
        $newRecipes = Recipe::query()->latest()->take(3)->get();
        return view('home', compact('newRecipes'));
    }

    public function index(Request $request)
    {
        $query = Recipe::query();

        if ($request->filled('category')) {
            $query->where('category', $request->string('category'));
        }

        if ($request->filled('q')) {
            $q = '%' . trim((string) $request->string('q')) . '%';
            $query->where(function ($inner) use ($q) {
                $inner->where('title', 'like', $q)
                    ->orWhere('description', 'like', $q)
                    ->orWhereHas('ingredients', function ($ingredientsQuery) use ($q) {
                        $ingredientsQuery->where('text', 'like', $q);
                    })
                    ->orWhereHas('steps', function ($stepsQuery) use ($q) {
                        $stepsQuery->where('text', 'like', $q);
                    });
            });
        }

        $recipes = $query->latest()->get();
        $favoriteIds = [];

        if (Auth::check()) {
            $favoriteIds = Auth::user()
                ->favoriteRecipes()
                ->pluck('recipe_id')
                ->all();
        }

        return view('recipes.index', [
            'recipes' => $recipes,
            'favoriteIds' => $favoriteIds,
            'query' => $request->string('q'),
            'currentCategory' => $request->string('category'),
        ]);
    }

    public function show(Recipe $recipe)
    {
        $recipe->load(['ingredients', 'steps']);
        $isFavorite = false;

        if (Auth::check()) {
            $isFavorite = Auth::user()
                ->favoriteRecipes()
                ->where('recipe_id', $recipe->id)
                ->exists();
        }

        return view('recipes.show', compact('recipe', 'isFavorite'));
    }

    public function create()
    {
        $this->authorizeAdminOrRedactor();
        return view('recipes.create');
    }

    public function store(Request $request)
    {
        $this->authorizeAdminOrRedactor();

        $data = $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'description' => ['required', 'string', 'max:2000'],
            'category' => ['required', 'string', 'max:50'],
            'calories' => ['required', 'numeric', 'min:0', 'max:100000'],
            'photo' => ['required', 'image', 'max:4096'],
            'ingredients_text' => ['required', 'string'],
            'steps_text' => ['required', 'string'],
        ]);

        DB::transaction(function () use ($data, $request) {
            $photoPath = $request->file('photo')->store('recipes', 'public');

            $recipe = Recipe::create([
                'title' => trim($data['title']),
                'description' => trim($data['description']),
                'category' => $data['category'],
                'calories' => $data['calories'],
                'photo_path' => '/storage/' . $photoPath,
            ]);

            $ingredients = $this->splitLines($data['ingredients_text']);
            foreach ($ingredients as $line) {
                $recipe->ingredients()->create(['text' => $line]);
            }

            $steps = $this->splitLines($data['steps_text']);
            foreach ($steps as $index => $line) {
                $recipe->steps()->create([
                    'step_number' => $index + 1,
                    'text' => $line,
                ]);
            }
        });

        return redirect()->route('recipes.index');
    }

    public function edit(Recipe $recipe)
    {
        $this->authorizeAdminOrRedactor();
        $recipe->load(['ingredients', 'steps']);
        return view('recipes.edit', compact('recipe'));
    }

    public function update(Request $request, Recipe $recipe)
    {
        $this->authorizeAdminOrRedactor();

        $data = $request->validate([
            'title' => ['required', 'string', 'max:120'],
            'description' => ['required', 'string', 'max:2000'],
            'category' => ['required', 'string', 'max:50'],
            'calories' => ['required', 'numeric', 'min:0', 'max:100000'],
            'photo' => ['nullable', 'image', 'max:4096'],
            'ingredients_text' => ['required', 'string'],
            'steps_text' => ['required', 'string'],
        ]);

        DB::transaction(function () use ($data, $request, $recipe) {
            $payload = [
                'title' => trim($data['title']),
                'description' => trim($data['description']),
                'category' => $data['category'],
                'calories' => $data['calories'],
            ];

            if ($request->hasFile('photo')) {
                if ($recipe->photo_path) {
                    $old = str_replace('/storage/', '', $recipe->photo_path);
                    Storage::disk('public')->delete($old);
                }
                $payload['photo_path'] = '/storage/' . $request->file('photo')->store('recipes', 'public');
            }

            $recipe->update($payload);
            $recipe->ingredients()->delete();
            $recipe->steps()->delete();

            foreach ($this->splitLines($data['ingredients_text']) as $line) {
                $recipe->ingredients()->create(['text' => $line]);
            }
            foreach ($this->splitLines($data['steps_text']) as $index => $line) {
                $recipe->steps()->create(['step_number' => $index + 1, 'text' => $line]);
            }
        });

        return redirect()->route('recipes.show', $recipe);
    }

    public function destroy(Recipe $recipe)
    {
        $this->authorizeAdminOrRedactor();

        if ($recipe->photo_path) {
            $old = str_replace('/storage/', '', $recipe->photo_path);
            Storage::disk('public')->delete($old);
        }

        $recipe->delete();
        return redirect()->route('recipes.index');
    }

    private function splitLines(string $text): array
    {
        $lines = preg_split('/\r\n|\r|\n/', $text);
        $lines = array_map(fn($line) => trim((string) $line), $lines);
        return array_values(array_filter($lines, fn($line) => $line !== ''));
    }

    private function authorizeAdminOrRedactor(): void
    {
        $user = Auth::user();
        abort_unless($user && in_array($user->role, ['Admin', 'Redactor'], true), 403);
    }
}
