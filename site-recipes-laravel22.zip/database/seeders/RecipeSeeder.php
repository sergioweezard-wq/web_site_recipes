<?php

namespace Database\Seeders;

use App\Models\Recipe;
use Illuminate\Database\Seeder;

class RecipeSeeder extends Seeder
{
    public function run(): void
    {

        foreach ($recipes as $item) {
            $recipe = Recipe::query()->updateOrCreate(
                ['title' => $item['title']],
                [
                    'description' => $item['description'],
                    'category' => $item['category'],
                    'calories' => $item['calories'],
                    'photo_path' => null,
                ]
            );

            $recipe->ingredients()->delete();
            $recipe->steps()->delete();

            foreach ($item['ingredients'] as $ingredient) {
                $recipe->ingredients()->create(['text' => $ingredient]);
            }

            foreach ($item['steps'] as $index => $stepText) {
                $recipe->steps()->create([
                    'step_number' => $index + 1,
                    'text' => $stepText,
                ]);
            }
        }
    }
}
